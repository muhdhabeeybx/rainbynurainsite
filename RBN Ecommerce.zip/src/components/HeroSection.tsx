import React from 'react';
import { Button } from './ui/button';
import { motion } from 'motion/react';
const heroImage = 'https://images.unsplash.com/photo-1580172275379-bf8077ea5b5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJlZXR3ZWFyJTIwZmFzaGlvbiUyMGJsYWNrJTIwdXJiYW58ZW58MXx8fHwxNzU5MjM3OTY0fDA&ixlib=rb-4.1.0&q=80&w=1080';

export function HeroSection() {
  const scrollToNewArrivals = () => {
    const newArrivalsSection = document.getElementById('new-arrivals');
    if (newArrivalsSection) {
      newArrivalsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      className="relative h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: `url(${heroImage})` }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/40"></div>
      
      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 max-w-5xl mx-auto hero-content mobile-keep-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="hero-section mobile-keep-center"
        >
          <h1 className="font-heading text-[56px] md:text-6xl lg:text-7xl mb-8 leading-tight tracking-tight">
            Left Home to Feed Home
          </h1>
          <p className="font-body text-lg md:text-xl mb-12 max-w-2xl mx-auto leading-relaxed text-white/90">
            Discover our latest collection of premium streetwear that tells your story
          </p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mobile-keep-center"
          >
            <Button
              size="sm"
              onClick={scrollToNewArrivals}
              className="bg-white text-black hover:bg-gray-100 font-normal tracking-wide px-8 py-3 text-sm uppercase mx-auto mobile-keep-center transition-all duration-200"
            >
              Shop Now
            </Button>
          </motion.div>
        </motion.div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/80"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
      >
        <div className="flex flex-col items-center">
          <p className="text-xs uppercase tracking-wider mb-2 font-body">Scroll</p>
          <div className="w-px h-8 bg-white/50"></div>
        </div>
      </motion.div>
    </section>
  );
}