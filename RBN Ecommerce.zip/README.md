
  # Rain by Nurain Streetwear E-commerce Website

  This is a code bundle for Rain by Nurain Streetwear E-commerce Website. The original project is available at https://www.figma.com/design/xxuw55CksLSCq3NksRfSgH/Rain-by-Nurain-Streetwear-E-commerce-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  